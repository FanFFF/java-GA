package GA;

public class Mainn {
    public static void main(String[] args){

        //�������õ�orederֱ����
        new GA().Ga(order);
        int ANS[][] = new int [200][200];
        int RNS[][] = new int [200][200];
        String ASS[][] = new String[200][200];
        String RSS[][] = new String[200][200];
        int mins = new GA().gettime();
        ANS = new GA().getAns();
        RNS = new GA().getRns();
        ASS = new GA().getAss();
        RSS = new GA().getRss();

        for(int i = 0; i < order.Mac_number; i++) {
            System.out.println("����:" + (i + 1));
            for (int j = 0; j < mins; j++) {
                System.out.print(" " + ANS[i][j]);
            }
            System.out.print("\n");
        }
        for(int i=0;i<order.Mac_number;i++){
            System.out.println("����:"+(i+1));
            for(int j=0;j<mins;j++){
                System.out.print(" |"+ASS[i][j]);
            }
            System.out.println();
        }
        for(int i = 1; i <= order.Work_number; i++) {
            System.out.println("����: "+i);
            for(int j = 0; j < mins; j++) {
                System.out.print(" "+RNS[i][j]);
            }
            System.out.print("\n");
        }
        for(int i=1;i<=order.Work_number;i++){
            System.out.println("����:"+i);
            for(int j=0;j<mins;j++){
                System.out.print(" |"+RSS[i][j]);
            }
            System.out.println("\n");
        }




    }
}
